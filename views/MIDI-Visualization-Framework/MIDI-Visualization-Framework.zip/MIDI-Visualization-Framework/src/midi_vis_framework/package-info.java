/**
 * 
 */
/**
 * @author Thomas Castleman
 *
 */
package midi_vis_framework;