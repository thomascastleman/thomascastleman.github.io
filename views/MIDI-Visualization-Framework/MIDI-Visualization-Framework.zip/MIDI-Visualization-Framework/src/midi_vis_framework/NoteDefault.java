package midi_vis_framework;

/**
 * Abstract class for default Note object. Should be extended by the actual Note class 
 * in which the user defines the attributes they would like a Note to have. These methods / members
 * are simply the default / minimum requirements for interacting with the NoteManager class.
 * 
 * <p>
 * Part of MIDI Visualizer library for helping to efficiently track notes as they are played
 * in a way that is useful for visualization.<br>
 * Built using Eclipse Neon IDE.
 * </p>
 * @author Thomas Castleman
 * 
 * @version 0.1b
 * 
 * @since 0.1b
 */

public abstract class NoteDefault {

	public int channel, velocity, pitch;   // channel, velocity and pitch of the note
	public int lifespan = 5;               // lifespan of note, in frames (default to 5 frames)
	public boolean isReleased;             // whether or not the note has been released yet
	
	/**
	 * Updates the properties of this note object.
	 * Should be user-defined, however they want to change 
	 * internal variables of each note.
	 */
	public void update() {
		
	}
	  
	/**
	 * Displays the note in some way on the canvas.
	 * Should be user-defined, howevery they want to visually
	 * represent the note being played.
	 */
	public void display() {
		
	}

}