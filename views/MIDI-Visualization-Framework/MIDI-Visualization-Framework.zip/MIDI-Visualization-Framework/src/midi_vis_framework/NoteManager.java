package midi_vis_framework;

import processing.core.*;
import java.util.ArrayList;
import java.util.ListIterator;

/**
 * Class for managing NoteDefault objects.
 * 
 * <p>
 * Helps manage issues with keeping a running list of note objects as they are 
 * detected by the Midibus library. Designed to aid with MIDI visualization programs.<br>
 * Built using Eclipse Neon IDE.
 * </p>
 * @author Thomas Castleman
 * 
 * @version 0.1b
 * 
 * @since 0.1b
 */

//NoteDefaultManager class manages the tracking of MIDI notes, as played live
public class NoteManager extends PApplet {

  public ArrayList<NoteDefault> notes = new ArrayList<NoteDefault>();            // all note objects currently being tracked
  private ArrayList<NoteDefault> notesToAdd = new ArrayList<NoteDefault>();      // notes to add to the list of tracked notes
  private ArrayList<NoteDefault> release = new ArrayList<NoteDefault>();         // notes that will be released on this iteration of the draw() loop
  private ArrayList<NoteDefault> notesToRelease = new ArrayList<NoteDefault>();  // notes waiting for the next iteration of draw() to be released
  
  /**
   * Constructor for creating a NoteManager
   */
  public NoteManager() { /* Empty constructor */ }

  /**
   * Adds a new note to be tracked
   * 
   * @param n The note object to be added
   */
  public void addNote(NoteDefault n) {
    // add note to list of notes that will be tracked in the next iteration of draw()
    notesToAdd.add(n);
  }

  /**
   * Releases a note object from being tracked by the manager
   * 
   * @param n The note object to be released (channel and pitch must match one of the notes currently being tracked)
   */
  public void releaseNote(NoteDefault n) {
    // add note to list of notes that will be released in the next iteration of draw()
    notesToRelease.add(n);
  }
  
  /**
   * Maintains the changing list of currently tracked notes. Avoids ConcurrentModificationExceptions by using 
   * a separate list for note to be added, notes to be released, and notes currently being tracked.
   * Should be run every iteration of draw()
   */
  public void track() {
    this.release.addAll(this.notesToRelease);  // add every note waiting to be released to list of notes about to be released
    this.notesToRelease.clear();  // remove everything from list of notes waiting to be released
    
    // for each note that needs to be released
    for (NoteDefault n : this.release) {
      // find its counterpart in the tracked notes array
      for (NoteDefault m : this.notes) {
        if (n.channel == m.channel && n.pitch == m.pitch) {
          m.isReleased = true;  // record that this note is now released
        }
      }
    }
    
    this.release.clear();  // remove everything from the list of notes to remove
    
    this.notes.addAll(this.notesToAdd);  // add every note waiting to be kept track of
    this.notesToAdd.clear();  // remove everything from list of notes waiting to be tracked
    
    // iterate through all notes currently being tracked
    ListIterator<NoteDefault> iter = this.notes.listIterator();
    while (iter.hasNext()) {
      NoteDefault n = iter.next();
      
      // if note has been released, decrement lifespan
      if (n.isReleased) {
        n.lifespan--;
      }
      
      // update and display each note
      n.update();
      n.display();
      
      // if a note is finished, remove from tracked notes
      if (n.lifespan <= 0) {
        iter.remove();
      }
    }
  }
}
